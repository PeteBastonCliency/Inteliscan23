import React from "react"

import OrionSprite from "../assets/svg/orion-svg-sprite.svg"

const SvgIcons = () => (
  <div style={{ position: "absolute" }}>
    <OrionSprite />
  </div>
)

export default SvgIcons
